MYSQL database will be used for this project
--Password is encrypted: Original is kushal@123